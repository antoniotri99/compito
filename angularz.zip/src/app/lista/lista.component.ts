import { Component } from '@angular/core';
import { Client, ClientService } from '../client.service';
import { EmailValidator, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrl: './lista.component.css'
})
export class ListaComponent {

  customers: Client[] = [];

  displayedColumns: string[] = ['nome', 'cognome', 'email','codiceFiscale','dataDiNascita','azienda', 'edit', 'delete'];
  
  userForm:FormGroup;
  selectdClientId: number | null = null;
  constructor (private clientService:ClientService, private fb: FormBuilder){
    this.userForm = this.fb.group({
      
      nome: ['', Validators.required],
      cognome: ['', Validators.required],
      email: ['', Validators.required],
      codiceFiscale: ['', Validators.required],
      dataDiNascita: ['', Validators.required],
      azienda: ['', Validators.required],

    });
    
  }



  



   ngOnInit(): void{
    this.getClient();
    
  }

  getClient(): void {
    let id = sessionStorage.getItem('userId');
    this.clientService.getClientsById(parseInt(id as string)).subscribe({
      next: (clients: Client[])=> {
        this.customers= clients;
  
      },
      error: (error: any)=>{
        console.error('errore recupero clienti',error);
      }
    });

  }

  onEdit(customer: Client): void {
    this.userForm.patchValue({
      nome:customer.nome,
      cognome:customer.cognome,
      email:customer.email,
      codiceFiscale:customer.codiceFiscale,
      dataDiNascita:customer.dataDiNascita,
      azienda:customer.azienda,
      

    });

    this.selectdClientId = customer.id !== undefined ? customer.id : null;
  }


  onSubmit(): void {
    if(this.userForm.valid) {
      if(this.selectdClientId === null) {
        let id = sessionStorage.getItem('userId');
        const cliente = {...this.userForm.value, userId: id};
        this.clientService.addClient(cliente).subscribe({
          next: (Response) => {
            this.getClient();
          },
          error: (error) => {
            console.error('Errore durante l\'aggiunta del cliente:', error);

          }
        });
      } else {
        let userId = sessionStorage.getItem('userId');
        const cliente = { ...this.userForm.value, userId: userId, id: this.selectdClientId };
        this.clientService.uptadeClient(cliente).subscribe ({
          next: (response) => {
            this.getClient();
            this.selectdClientId = null;
          },
          error:(error) => {
            console.error('Errore durante l\'aggiornamento del cliente:', error);
          }
        });
      }
    }
  }

  onDelete(clientId: number): void {
    if (confirm('Sei sicuro di voler eliminare questo cliente?')) {
      this.clientService.deleteClient(clientId).subscribe({
        next: () => {
          console.log(`Cliente con ID ${clientId} eliminato con successo.`);
          this.getClient(); // Aggiorna la lista dei clienti
        },
        error: (error) => {
          console.error(`Errore durante l'eliminazione del cliente con ID ${clientId}:`, error);
        }
      });
    }
  }
}

